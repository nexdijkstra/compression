#include<stdio.h>

int main(int argc, char *argv[])
{
				FILE *read;
				FILE *write;
				int bin=0;
				int zero_cnt=0;
				int zero_flag=0;
				if((read=fopen(argv[1],"rb"))==NULL)
				{
								printf("read file open error\n");
								return 0;
				}
				if((write=fopen(argv[2],"wb"))==NULL)
				{
								printf("write file open error\n");
								return 0;
				}

				while((bin=fgetc(read))!=EOF)
				{
								if(zero_cnt==255)
								{
												fputc(255,write);
												zero_flag=0;
												zero_cnt=0;
								}
								if(bin==0&&zero_flag==0)
								{
												fputc(bin,write);
												zero_flag++;
												continue;
								}else if (bin==0&&zero_flag!=0){
												if(zero_cnt<255)
												{
																zero_cnt++;
												}
												continue;				
								}else if(bin!=0)
								{
												if(zero_flag!=0){
																fputc(zero_cnt,write);
																fputc(bin,write);
																zero_cnt=0;
																zero_flag=0;
												}else
												{
																fputc(bin,write);
																zero_cnt=0;
																zero_flag=0;
												}
												continue;
								}
				}
				fclose(read);
				fclose(write);

}
