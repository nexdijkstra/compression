#include<stdio.h>

int main(int argc, char *argv[])
{
				FILE *read;
				FILE *write;
				char filename[511];
				int bin=0;
				int zero_cnt=0;
				int zero_flag=0;
				if((read=fopen(argv[1],"rb"))==NULL)
				{
								printf("read file open error\n");
								return 0;
				}
				if((write=fopen(argv[2],"wb"))==NULL)
				{
								printf("write file open error\n");
								return 0;
				}

				while((bin=fgetc(read))!=EOF)
				{
								if(zero_flag!=0)
								{
												zero_cnt=bin;
												while(zero_cnt!=0)
												{
																putc(0,write);
																zero_cnt--;
												}
												zero_cnt=0;
												zero_flag=0;
												continue;
								}

								if(bin==0&&zero_flag==0)
								{
												fputc(bin,write);
												zero_flag++;
												continue;

								}else if(bin!=0)
								{
												fputc(bin,write);
												zero_cnt=0;
												zero_flag=0;
												continue;
								}
				}
        sprintf(filename,"chmod 775 %s",argv[2]);
				system(filename);				
				fclose(read);
				fclose(write);
				return 0;
}
