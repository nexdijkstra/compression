1. 압축하기
1-1 compression 파일을 실행한다. 실행 명령어 뒤에  매개변수로 압축할 파일명과 압축하여 나오는 파일명을 입력한다.
ex) ./compression src dst

2. 압출 풀기
2-1 decompresion 파일을 실행한다. 실행 명령어 뒤에 compression으로 만든 파일명과 압축을 풀었을 때 실행되는 파일명을 입력한다.
ex) ./decompression src dst
